package com.mycompany.proyecto1;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

public class Evento {
String estado;
int personasMAX;
String creador;
public String tipo;
public String codigo;
public String titulo;
public String descripcion;
Calendar fecha;
public int personas;
public double monto;
public double total;

public ArrayList<teamMember> equipo1= new ArrayList<teamMember>();
    public ArrayList<teamMember> equipo2=new ArrayList<teamMember>();
    public ArrayList<teamMember> banda = new ArrayList<teamMember>();

    
    public void addTeam(String nombre, String rol, String equipo){
        teamMember tm= new teamMember(nombre, rol);
        if(equipo.equals("equipo 1")){
            equipo1.add(tm);
        }else if(equipo.equals("equipo 2")){
            equipo2.add(tm);
        }else if(equipo.equals("Musical")){
            banda.add(tm);
        }
    }
    
public String getExtraInfo(){
    return "";
}

public double getTotal(){
    return total;
}

public void setTotal(double total){
    this.total=total;
}

public void setEstado(String estado){
    this.estado=estado;
}

public void generateEstado(){
    if(fecha.before(Calendar.getInstance())){
        estado="Realizado";
    }else{
     estado="Futuro";
    }
    
}

public String getEstado(){
    return estado;
}

public int getMAX(){
    return personasMAX;
}

public String getCreador(){
    return creador;
}

public final void setCreador(String creador){
    this.creador=creador;
}

public Evento (String codigo){
    this.codigo=codigo;
}

    public String getTipo() {
        return tipo;
    }
    
    public void setTipo(String tipo){
        this.tipo=tipo;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public int getPersonas() {
        return personas;
    }

    public void setPersonas(int personas) {
        this.personas = personas;
    }

    public double getMonto() {
        return monto;
    }

    public void setMonto(double monto) {
        this.monto = monto;
    }  
    
    public Calendar getFecha(){
        return fecha;
    }
    
    public String getFechaString(){
        int mes=fecha.get(Calendar.DAY_OF_MONTH)+1;
        return(fecha.get(Calendar.MONTH)+" / "+mes+" / "+fecha.get(Calendar.YEAR));
    }
    
    public void setFecha(Calendar fecha){
        this.fecha=fecha;
    }

}
