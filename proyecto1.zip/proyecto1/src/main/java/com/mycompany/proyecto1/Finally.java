package com.mycompany.proyecto1;

public final class Finally {
    public static int religiosoMAX=30;
    public static int musicalMAX=25;
    public static int deportivoMAX=20; 
}
