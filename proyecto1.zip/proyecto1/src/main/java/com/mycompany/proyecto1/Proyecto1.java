package com.mycompany.proyecto1;

import view.loginWIN;

public class Proyecto1 {

    public static void main(String[] args) {
        Usuario admin= new UsuarioAdministrador("admin","supersecreto");
        stored.usuarios.add(admin);
        new loginWIN().setVisible(true);
    }
}
