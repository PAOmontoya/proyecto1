package com.mycompany.proyecto1;

public class UsuarioAdministrador extends Usuario{
    
    public UsuarioAdministrador(String username, String password) {
        super(username, password);
    }
    
    @Override
    public String getTipo(){
       return "Administrativo";
    }
    
}
