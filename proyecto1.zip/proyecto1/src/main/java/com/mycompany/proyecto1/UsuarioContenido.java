/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyecto1;

/**
 *
 * @author telip
 */
public class UsuarioContenido extends Usuario{
    
    public UsuarioContenido(String username, String password) {
        super(username, password);
    }
    
    @Override
    public String getTipo(){
        return "Contenido";
    }
    
}
