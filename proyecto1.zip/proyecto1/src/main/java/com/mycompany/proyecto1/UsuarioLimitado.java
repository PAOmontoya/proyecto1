package com.mycompany.proyecto1;

/**
 *
 * @author telip
 */
public class UsuarioLimitado extends Usuario{
    
    public UsuarioLimitado(String username, String password) {
        super(username, password);
    }
    
    @Override
    public String getTipo(){
        return "Limitado";
    }
    
}
