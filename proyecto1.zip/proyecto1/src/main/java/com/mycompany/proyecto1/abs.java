package com.mycompany.proyecto1;

public interface abs {
public String getRol();
public void setRol(String tipo);
public String getNombre();
public void setNombre(String nombre);
}
