package com.mycompany.proyecto1;

import java.util.ArrayList;

public class eventoDEPORTIVO extends Evento{
    String deporte;
    int personasMAX=20;
    
    @Override
    public String getExtraInfo(){
        return("Deporte: "+deporte);
    }
    
    @Override
    public String getTipo(){
        return "Deportivo";
    }
    
    public void setDeporte(String deporte){
        this.deporte=deporte;
    }
    
    public eventoDEPORTIVO(String codigo) {
        super(codigo);
    }
    
}
