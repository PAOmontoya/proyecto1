package com.mycompany.proyecto1;

import java.util.ArrayList;

public class eventoMUSICAL extends Evento{
    int personasMAX=25;
    String musica;
    
    
    public eventoMUSICAL(String codigo) {
        super(codigo);
    }
    
    public void setMusica(String musica){
        this.musica=musica;
    }
    
    @Override
    public String getExtraInfo(){
        return ("Musica: "+musica);
    }
    
    @Override
    public String getTipo(){
        return "Musical";
    }
    
}
