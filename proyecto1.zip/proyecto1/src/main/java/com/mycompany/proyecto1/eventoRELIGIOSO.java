package com.mycompany.proyecto1;

public class eventoRELIGIOSO extends Evento{
    int personasConvertidas;
    int personasMAX=30;
    public eventoRELIGIOSO(String codigo) {
        super(codigo);
    }

    public int getPersonasConvertidas() {
        return personasConvertidas;
    }

    public void convertir(int personas){
        personasConvertidas+=personas;
    }
    
    public void setConvertidas(int convertidas){
        this.personasConvertidas=convertidas;
    }
    
    @Override
    public String getExtraInfo(){
        return ("Personas convertidas: "+personasConvertidas);
    }
    
    @Override
    public String getTipo(){
        return "Religioso";
    }
    
}
