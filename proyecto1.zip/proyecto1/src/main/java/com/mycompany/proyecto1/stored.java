package com.mycompany.proyecto1;
import java.util.ArrayList;
import java.util.Calendar;

public class stored{
    //users
public static ArrayList<Usuario> usuarios=new ArrayList<Usuario>();
public static Usuario logged=new Usuario("","");
public Usuario admin= new UsuarioAdministrador("admin","supersecreto");

public stored(){
stored.usuarios.add(admin);    
}

public static void Logged(String username){
    for(int i=0; i<stored.usuarios.size();i++){
    Usuario usuario=stored.usuarios.get(i);
    String userName=usuario.getUsername();
    if(userName.equals(username)){
        logged=usuario;
    }
}    
}

//recursividad #2
public static boolean usuarioRepetido(String username, int i, Usuario ex) {
    if (i>=0 && i<stored.usuarios.size()) {
        Usuario user = stored.usuarios.get(i);
        String userName = user.getUsername();

        if (username.equals(userName) && !user.equals(ex)) {
            return true;
        } else {
            return usuarioRepetido(username, i+1,ex);
        }
    }
    return false; 
}

public static ArrayList<Evento> eventos=new ArrayList<Evento>();


//recursividad #3
public static Evento findEvent(String codigo, int index) {
    if (index <stored.eventos.size()) {
        Evento event =stored.eventos.get(index);
        String code =event.getCodigo();
        if (codigo.equals(code)) {
            return event;
        } else {
            return findEvent(codigo, index +1);
        }
    }
    return null;
}


}
