package com.mycompany.proyecto1;

public class teamMember implements abs{
    String nombre;
    String rol;
    
    public teamMember(String nombre, String rol){
        this.rol=rol;
        this.nombre=nombre;
    }

    @Override
    public String getRol() {
        return rol;
    }

    @Override
    public void setRol(String rol) {
        this.rol=rol;
    }

    @Override
    public String getNombre() {
        return nombre;
    }

    @Override
    public void setNombre(String nombre) {
        this.nombre=nombre;
    }

    
}
