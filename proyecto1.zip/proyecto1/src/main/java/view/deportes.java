package view;

public enum deportes {
FUTBOL,TENIS,RUGBY,BASEBALL    
}
